import sys
from PyQt5 import QtWidgets
from main_window import Ui_Building  # Сгенерированный файл интерфейса
from cls_structure import Structure
from cls_sale import Sale


class MainApp(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Building()
        self.ui.setupUi(self)

        self.structure_db = Structure()
        self.sale_db = Sale()
        self.current_table = "Sale"

        # Подключение кнопок
        self.ui.pushButton_View_Structure.clicked.connect(self.show_structure)
        self.ui.pushButton_View_Sale.clicked.connect(lambda: self.show_sale())
        self.ui.pushButton_Add_2.clicked.connect(self.add_sale)
        self.ui.pushButton_Delete_2.clicked.connect(self.delete_selected_row)
        self.ui.pushButton.clicked.connect(self.add_structure)
        self.ui.pushButton_2.clicked.connect(self.sort_sale_asc)
        self.ui.pushButton_3.clicked.connect(self.sort_sale_desc)
        self.ui.pushButton_4.clicked.connect(self.reset_filters_and_sorting)
        self.ui.comboBox_2.currentIndexChanged.connect(self.filter_sale_by_structure)

        self.load_comboboxes()
        self.show_sale()

    def load_comboboxes(self):
        self.ui.comboBox.clear()
        self.ui.comboBox_2.clear()
        structures = self.structure_db.view()
        for id_, name in structures:
            self.ui.comboBox.addItem(name, id_)
            self.ui.comboBox_2.addItem(name, id_)
        self.ui.comboBox_2.setCurrentIndex(-1)

    def show_structure(self):
        self.current_table = "Structure"
        self.ui.tableWidget.setRowCount(0)
        self.ui.tableWidget.setColumnCount(2)
        self.ui.tableWidget.setHorizontalHeaderLabels(["ID", "Тип строения"])
        data = self.structure_db.view()
        for row_idx, row in enumerate(data):
            self.ui.tableWidget.insertRow(row_idx)
            for col_idx, value in enumerate(row):
                self.ui.tableWidget.setItem(row_idx, col_idx, QtWidgets.QTableWidgetItem(str(value)))

    def show_sale(self, data=None):
        try:
            self.current_table = "Sale"
            self.ui.tableWidget.setRowCount(0)
            self.ui.tableWidget.setColumnCount(5)
            self.ui.tableWidget.setHorizontalHeaderLabels(
                ["ID", "Тип строения", "Кол-во комнат", "Метраж", "Цена"]
            )
            if data is None:
                data = self.sale_db.view_with_type()
            for row_idx, row in enumerate(data):
                self.ui.tableWidget.insertRow(row_idx)
                for col_idx, value in enumerate(row):
                    self.ui.tableWidget.setItem(row_idx, col_idx, QtWidgets.QTableWidgetItem(str(value)))
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Ошибка", f"Ошибка при загрузке данных: {e}")

    def add_sale(self):
        try:
            type_id = self.ui.comboBox.currentData()
            if type_id is None:
                raise ValueError("Не выбран тип строения")

            num_rooms = int(self.ui.lineEdit.text())
            footage = float(self.ui.lineEdit_3.text())
            price = float(self.ui.lineEdit_2.text())

            if num_rooms <= 0 or footage <= 0 or price <= 0:
                QtWidgets.QMessageBox.warning(
                    self, "Ошибка",
                    "Значения количества комнат, метража и цены должны быть положительными и больше нуля."
                )
                return

            self.sale_db.insert(type_id, num_rooms, footage, price)
            self.show_sale()

            # Очистка полей после добавления
            self.ui.lineEdit.clear()
            self.ui.lineEdit_2.clear()
            self.ui.lineEdit_3.clear()

        except ValueError:
            QtWidgets.QMessageBox.warning(
                self, "Ошибка", "Пожалуйста, введите корректные числовые значения."
            )

    def add_structure(self):
        new_type = self.ui.lineEdit_4.text()
        if new_type.strip():
            self.structure_db.insert(new_type)
            self.load_comboboxes()
            self.ui.lineEdit_4.clear()
        else:
            QtWidgets.QMessageBox.warning(self, "Ошибка", "Введите название типа строения.")

    def delete_selected_row(self):
        selected = self.ui.tableWidget.currentRow()
        if selected < 0:
            QtWidgets.QMessageBox.warning(self, "Ошибка", "Выберите строку для удаления.")
            return

        id_item = self.ui.tableWidget.item(selected, 0)
        if not id_item:
            QtWidgets.QMessageBox.warning(self, "Ошибка", "Не удалось получить ID.")
            return

        try:
            id_value = int(id_item.text())
            if self.current_table == "Sale":
                self.sale_db.cur.execute("DELETE FROM Sale WHERE id = ?", (id_value,))
                self.sale_db.con.commit()
                self.show_sale()

            elif self.current_table == "Structure":
                self.structure_db.cur.execute("DELETE FROM Structure WHERE id_building = ?", (id_value,))
                self.structure_db.con.commit()
                self.show_structure()
                self.load_comboboxes()

        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Ошибка", f"Ошибка удаления: {e}")

    def sort_sale_asc(self):
        if self.current_table != "Sale":
            return
        data = sorted(self.sale_db.view_with_type(), key=lambda x: x[4])
        self.show_sale(data)

    def sort_sale_desc(self):
        if self.current_table != "Sale":
            return
        data = sorted(self.sale_db.view_with_type(), key=lambda x: x[4], reverse=True)
        self.show_sale(data)

    def filter_sale_by_structure(self):
        if self.current_table != "Sale":
            return
        struct_name = self.ui.comboBox_2.currentText()
        if not struct_name:
            return
        all_data = self.sale_db.view_with_type()
        filtered = [row for row in all_data if row[1] == struct_name]
        self.show_sale(filtered)

    def reset_filters_and_sorting(self):
        if self.current_table == "Sale":
            self.ui.comboBox_2.setCurrentIndex(-1)
            self.show_sale()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = MainApp()
    window.show()
    sys.exit(app.exec_())

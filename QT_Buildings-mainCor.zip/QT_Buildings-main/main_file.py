import sys
from PyQt5 import QtWidgets, QtCore
from main_window import Ui_Building  # Сгенерированный файл интерфейса
from cls_structure import Structure
from cls_sale import Sale


class MainApp(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Building()
        self.ui.setupUi(self)

        self.structure_db = Structure()
        self.sale_db = Sale()
        self.current_table = "Sale"

        # Подключение кнопок
        self.ui.pushButton_View_Structure.clicked.connect(self.show_structure)
        self.ui.pushButton_View_Sale.clicked.connect(lambda: self.show_sale())
        self.ui.pushButton_Add_2.clicked.connect(self.add_sale)
        self.ui.pushButton_Delete_2.clicked.connect(self.delete_selected_row)
        self.ui.pushButton.clicked.connect(self.add_structure)
        self.ui.pushButton_2.clicked.connect(self.sort_sale_asc)
        self.ui.pushButton_3.clicked.connect(self.sort_sale_desc)
        self.ui.pushButton_4.clicked.connect(self.reset_filters_and_sorting)
        self.ui.comboBox_2.currentIndexChanged.connect(self.filter_sale_by_structure)
        self.ui.pushButton_Add_3.clicked.connect(self.search_by_building_type)

        # Добавим метки для статистики
        self.stats_label = QtWidgets.QLabel(self.ui.centralwidget)
        self.stats_label.setGeometry(QtCore.QRect(270, 450, 500, 100))
        self.stats_label.setObjectName("stats_label")

        self.load_comboboxes()
        self.show_sale()

    def load_comboboxes(self):
        self.ui.comboBox.clear()
        self.ui.comboBox_2.clear()
        structures = self.structure_db.view()
        for id_, name in structures:
            self.ui.comboBox.addItem(name, id_)
            self.ui.comboBox_2.addItem(name, id_)
        self.ui.comboBox_2.setCurrentIndex(-1)

    def show_structure(self):
        self.current_table = "Structure"
        self.ui.tableWidget.setRowCount(0)
        self.ui.tableWidget.setColumnCount(2)
        self.ui.tableWidget.setHorizontalHeaderLabels(["ID", "Тип строения"])
        data = self.structure_db.view()
        for row_idx, row in enumerate(data):
            self.ui.tableWidget.insertRow(row_idx)
            for col_idx, value in enumerate(row):
                self.ui.tableWidget.setItem(row_idx, col_idx, QtWidgets.QTableWidgetItem(str(value)))
        self.stats_label.clear()

    def show_sale(self, data=None):
        try:
            self.current_table = "Sale"
            self.ui.tableWidget.setRowCount(0)
            self.ui.tableWidget.setColumnCount(5)
            self.ui.tableWidget.setHorizontalHeaderLabels(
                ["ID", "Тип строения", "Кол-во комнат", "Метраж", "Цена"]
            )
            if data is None:
                data = self.sale_db.view_with_type()

            for row_idx, row in enumerate(data):
                self.ui.tableWidget.insertRow(row_idx)
                for col_idx, value in enumerate(row):
                    self.ui.tableWidget.setItem(row_idx, col_idx, QtWidgets.QTableWidgetItem(str(value)))

            # Обновляем статистику
            self.update_stats(data)

        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Ошибка", f"Ошибка при загрузке данных: {e}")

    def update_stats(self, data):
        if not data:
            self.stats_label.setText("Нет данных для отображения статистики")
            return

        # Вычисляем статистику
        count = len(data)
        prices = [float(row[4]) for row in data]
        footages = [float(row[3]) for row in data]

        min_price = min(prices)
        max_price = max(prices)
        avg_footage = sum(footages) / count

        stats_text = (f"Количество строений: {count}\n"
                      f"Средний метраж: {avg_footage:.2f} м²\n"
                      f"Минимальная цена: {min_price:.2f} руб.\n"
                      f"Максимальная цена: {max_price:.2f} руб.")

        self.stats_label.setText(stats_text)

    def search_by_building_type(self):
        search_text = self.ui.lineEdit_5.text().strip().lower()
        if not search_text:
            QtWidgets.QMessageBox.warning(self, "Ошибка", "Введите текст для поиска")
            return

        data = self.sale_db.view_with_type()
        filtered = [row for row in data if search_text in row[1].lower()]

        if not filtered:
            QtWidgets.QMessageBox.information(self, "Результат", "Совпадений не найдено")
            return

        self.show_sale(filtered)

    def add_sale(self):
        try:
            type_id = self.ui.comboBox.currentData()
            if type_id is None:
                raise ValueError("Не выбран тип строения")

            num_rooms = int(self.ui.lineEdit.text())
            footage = float(self.ui.lineEdit_3.text())
            price = float(self.ui.lineEdit_2.text())

            if num_rooms <= 0 or footage <= 0 or price <= 0:
                QtWidgets.QMessageBox.warning(
                    self, "Ошибка",
                    "Значения количества комнат, метража и цены должны быть положительными и больше нуля."
                )
                return

            self.sale_db.insert(type_id, num_rooms, footage, price)
            self.show_sale()

            # Очистка полей после добавления
            self.ui.lineEdit.clear()
            self.ui.lineEdit_2.clear()
            self.ui.lineEdit_3.clear()

        except ValueError:
            QtWidgets.QMessageBox.warning(
                self, "Ошибка", "Пожалуйста, введите корректные числовые значения."
            )

    def add_structure(self):
        new_type = self.ui.lineEdit_4.text()
        if new_type.strip():
            self.structure_db.insert(new_type)
            self.load_comboboxes()
            self.ui.lineEdit_4.clear()
        else:
            QtWidgets.QMessageBox.warning(self, "Ошибка", "Введите название типа строения.")

    def delete_selected_row(self):
        selected = self.ui.tableWidget.currentRow()
        if selected < 0:
            QtWidgets.QMessageBox.warning(self, "Ошибка", "Выберите строку для удаления.")
            return

        id_item = self.ui.tableWidget.item(selected, 0)
        if not id_item:
            QtWidgets.QMessageBox.warning(self, "Ошибка", "Не удалось получить ID.")
            return

        try:
            id_value = int(id_item.text())
            if self.current_table == "Sale":
                self.sale_db.cur.execute("DELETE FROM Sale WHERE id = ?", (id_value,))
                self.sale_db.con.commit()
                self.show_sale()

            elif self.current_table == "Structure":
                self.structure_db.cur.execute("DELETE FROM Structure WHERE id_building = ?", (id_value,))
                self.structure_db.con.commit()
                self.show_structure()
                self.load_comboboxes()

        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Ошибка", f"Ошибка удаления: {e}")

    def sort_sale_asc(self):
        if self.current_table != "Sale":
            return
        data = sorted(self.sale_db.view_with_type(), key=lambda x: x[4])
        self.show_sale(data)

    def sort_sale_desc(self):
        if self.current_table != "Sale":
            return
        data = sorted(self.sale_db.view_with_type(), key=lambda x: x[4], reverse=True)
        self.show_sale(data)

    def filter_sale_by_structure(self):
        if self.current_table != "Sale":
            return
        struct_name = self.ui.comboBox_2.currentText()
        if not struct_name:
            return
        all_data = self.sale_db.view_with_type()
        filtered = [row for row in all_data if row[1] == struct_name]
        self.show_sale(filtered)

    def reset_filters_and_sorting(self):
        if self.current_table == "Sale":
            self.ui.comboBox_2.setCurrentIndex(-1)
            self.ui.lineEdit_5.clear()
            self.show_sale()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = MainApp()
    window.show()
    sys.exit(app.exec_())